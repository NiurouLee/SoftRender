Credits to Samuel (arshlevon) Sharit
---

Date: Tue, 27 Jan 2015 19:24:30 -0800
From: Samuel Sharit <arshlevon@gmail.com>
To: Dmitry Sokolov <dmitry.sokolov@loria.fr>
Subject: Re: diablo posing

Go for it!

[cut]

